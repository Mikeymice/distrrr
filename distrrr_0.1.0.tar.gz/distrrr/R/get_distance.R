
#' get_distance
#'
#' @param point1
#' @param point2
#' @param metric
#'
#' @return float, the distance between point1 and point2 based on the metric given
#' @export
#'
#' @examples
get_distance <- function(point1, point2, metric)
{

  return(-1) # dummy result
}
