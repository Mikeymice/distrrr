library(testthat)
library(distrrr)

test_check("distrrr")
